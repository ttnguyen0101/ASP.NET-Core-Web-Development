using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using ThuPureBoutique.Models;

namespace ThuPureBoutique.Controllers
{
    public class ContactController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(ContactModel model)
        {
            return View(model);
        }
    }
}