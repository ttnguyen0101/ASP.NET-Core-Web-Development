﻿
namespace ThuPureBoutique.Models
{
    public class ProductData
    {
        public static List<ProductModel> GetProducts() 
        {
            List<ProductModel> products = new List<ProductModel> 
            {
                new ProductModel {
                    ProductId = 1,
                    ProductName = "Jacket",
                    ProductDescription = "Midnight Annika Jacket",
                    ProductImage = "AnnikaJacket.jpg",
                    ProductPrice = 458
                },

                new ProductModel {
                    ProductId = 2,
                    ProductName = "Jumpsuit",
                    ProductDescription = "Denim Jumpsuit",
                    ProductImage = "DenimJumpsuit.jpg",
                    ProductPrice = 268
                },

                new ProductModel {
                    ProductId = 3,
                    ProductName = "Sweater",
                    ProductDescription = "Maron Ester Sweater",
                    ProductImage = "EsterSweater.jpg",
                    ProductPrice = 398
                },

                new ProductModel {
                    ProductId = 4,
                    ProductName = "Skirt",
                    ProductDescription = "Sky Gingham Eva Skirt",
                    ProductImage = "EvaSkirt.jpg",
                    ProductPrice = 228
                },

                new ProductModel {
                    ProductId = 5,
                    ProductName = "Dress",
                    ProductDescription = "Fauna Black Flower Dress",
                    ProductImage = "FlowerDress.jpg",
                    ProductPrice = 298
                },

                new ProductModel {
                    ProductId = 6,
                    ProductName = "Blouse",
                    ProductDescription = "Mums Ditsy Black Sammi Blouse",
                    ProductImage = "SammiBlouse.jpg",
                    ProductPrice = 188
                }
            };

            return products;
        }

        public static ProductModel GetProduct(int id) 
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products) 
            {
                if (product.ProductId == id) 
                {
                    return product;
                }
            }
            return new ProductModel();
        }
    }

}

