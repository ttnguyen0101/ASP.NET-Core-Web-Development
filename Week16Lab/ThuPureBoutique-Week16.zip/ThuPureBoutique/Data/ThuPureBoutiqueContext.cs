﻿using Microsoft.EntityFrameworkCore;
using ThuPureBoutique.Models;

namespace ThuPureBoutique.Data
{
    public class ThuPureBoutiqueContext : DbContext
    {
        public ThuPureBoutiqueContext(DbContextOptions<ThuPureBoutiqueContext> options) : base(options)
        { }

        public DbSet<ProductModel> ProductDb { get; set; } = null! ;
        public DbSet<ContactModel> ContactDb { get; set; } = null! ;
    }
}
