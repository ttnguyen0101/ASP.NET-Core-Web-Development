using System.ComponentModel.DataAnnotations;

namespace ThuPureBoutique.Models
{
    public class ContactModel
    {
        [Required(ErrorMessage = "Please enter a first name.")]
        [StringLength(30, ErrorMessage = "First name must be 30 characters or less.")]
        [RegularExpression("^[a-zA-Z]+$", ErrorMessage = "First name may not contain special characters or numbers.")]
        //attributes combined to 1 line: [RegularExpression(), Required, StringLength()]
        public string? FirstName { get; set; }

        [Required(ErrorMessage = "Please enter a last name.")]
        [StringLength(30, ErrorMessage = "Last name must be 30 characters or less.")]
        [RegularExpression("^[a-zA-Z]+$", ErrorMessage = "Last name may not contain special characters or numbers.")]
        public string? LastName { get; set; }

        [Required(ErrorMessage = "Please enter an address.")]
        [EmailAddress(ErrorMessage = "Please enter an email address.")]
        public string? Address { get; set; }

        [Required(ErrorMessage = "Please enter a phone numbers.")]
        [StringLength(10, ErrorMessage = "Phone numbers must be 10 digits.")]
        [RegularExpression("^[0-9]{10}$", ErrorMessage = "Phone numbers may only contain numbers.")]
        public string? Phone { get; set; }

        [Required(ErrorMessage = "Please enter an email.")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Please enter a message.")]
        public string? Message { get; set; }

    }
}