﻿using System.ComponentModel.DataAnnotations;

namespace ThuPureBoutique.Models 
{
    public class ProductModel
    {
        public int ProductId { get; set; }
         
        [Required(ErrorMessage ="Must have product name.")]
        public string ProductName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Must have product description.")]
        public string ProductDescription { get; set; } = string.Empty;

        [Required(ErrorMessage = "Must have product image.")]
        public string ProductImage { get; set; } = string.Empty;

        [DataType(DataType.Currency)]
        public decimal ProductPrice { get; set; }
    }
}



